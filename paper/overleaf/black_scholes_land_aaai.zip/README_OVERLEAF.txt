Black-Scholes for the Land (AAAI-27 format, not anonymised)

Overleaf settings (Menu):
  Compiler: pdfLaTeX          (the AAAI-27 style refuses XeLaTeX/LuaLaTeX)
  Main document: main.tex     (switch to supplement.tex to build the supplement PDF)

main.tex and supplement.tex cross-reference each other with the xr package
(e.g. "Table A1", "Figure 2"). xr reads the other document's .aux file, so
main.aux and supplement.aux are included pre-built. If you renumber tables or
figures in one document, rebuild the other (switch Main document, recompile,
then download its .aux from Logs and output files and upload it here) to refresh
the cross-references.
